 rm test_videos_output/*
 rm test_images_output/*
